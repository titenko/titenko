#ifndef __LOCALDECLS_H_
#define __LOCALDECLS_H_

#define TRUNCATE_T off_t
#define READLINKAT_T ssize_t
#define LIBC_FILE "libc.so.6"
#define LIBC_VERSION "2.31"
#define GLIBC_MAJOR 2
#define GLIBC_MINOR 31

#endif
